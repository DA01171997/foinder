package com.example.project1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class FindOption extends AppCompatActivity {
    private SeekBar radiusBar;
    private TextView radius;
    private Button findButton;
    private int seekValue;
    private static final String TAG = "FindOption";
    private String name="";
    private int userID;
    private double lon;
    private double lat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Context context;
        setContentView(R.layout.activity_find_option);
        radiusBar = (SeekBar) findViewById(R.id.distance_bar);
        radius = (TextView) findViewById(R.id.radiustv);
        findButton = (Button) findViewById(R.id.findButton);
        //maxValue = radiusBar.getMax();
        seekValue = radiusBar.getProgress();
        Intent intent = getIntent();
        name = intent.getExtras().getString("name").toUpperCase();
        userID = intent.getExtras().getInt("userID");
        lon = intent.getExtras().getDouble("lon");
        lat = intent.getExtras().getDouble("lat");

        Log.i(TAG,"STUFFF "+ name + " "+ userID + " "+ lon + " "+ lat + " " + seekValue);

        radiusBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekValue = progress;
                radius.setText(String.valueOf(seekValue)+" meters");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //.makeText(seekBar.getContext(), "Seek bar progress is :" + progressChangedValue,
                 //       Toast.LENGTH_SHORT).show();
            }
        });
        findButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findRestaurant();
            }
        });
    }
    public void findRestaurant(){
        Log.i(TAG,"Find "+ name + " "+ userID + " "+ lon + " "+ lat + " " + seekValue);
    }
}

package com.example.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainOption extends AppCompatActivity {
    private Button findRestaurantBtn;
    private Button profileBtn;
    private Button historyBtn;
    private Button logoutBtn;
    private TextView welcometv;
    private TextView nametv;
    private String name;
    private int userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_option);
        Intent intent = getIntent();
        name = intent.getExtras().getString("name").toUpperCase();
        userID = intent.getExtras().getInt("userID");
        findRestaurantBtn = (Button) findViewById(R.id.findbutton);
        profileBtn = (Button) findViewById(R.id.profileButton);
        historyBtn = (Button) findViewById(R.id.historyButton);
        logoutBtn = (Button) findViewById(R.id.logoutButton);
        nametv = (TextView) findViewById(R.id.nametv);
        nametv.setText(name);

    }
}

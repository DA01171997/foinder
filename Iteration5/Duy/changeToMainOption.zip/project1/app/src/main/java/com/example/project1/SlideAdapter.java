package com.example.project1;

import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Context;
import android.graphics.Color;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SlideAdapter extends PagerAdapter {
    Context context;
    LayoutInflater inflater;

    //list of images
    public int[] list_images={
            R.drawable.bspg,
            R.drawable.burger,
            R.drawable.cake,
            R.drawable.ice_cream,
            R.drawable.ramen,
            R.drawable.tmgyk,
            R.drawable.torr,
    };

    //list of titles
    public String[] list_title={
            "Apple in hot toffee",
            "Cheeses burger",
            "Cake",
            "Ice Cream",
            "Ramen",
            "Tamagoyaki",
            "katsu"
    };

    //list of descriptions
    public String[] list_descruption = {
            "Apple in hot toffee",
            "In N Out-Cheeses burger",
            "85 °C-cake",
            "Somi Somi-Taiyaki with matcha ice cream",
            "Daikokuya-Tonkatsu ramen",
            "Tamagoyaki",
            "Kimukatsu-Katsu set"
    };

    //list of background colors
    public int[] list_backgroundcolor={
            Color.rgb(20,50,100),
            Color.rgb(0,100,45),
            Color.rgb(255,150,0),
            Color.rgb(145,255,255),
            Color.rgb(159,50,200),
            Color.rgb(255,255,100),
            Color.rgb(255,30,30),
    };


    public SlideAdapter(Context context){
        this.context=context;
    }

    @Override
    public int getCount() {
        return list_title.length;
    }


    @Override
    public boolean isViewFromObject( View view,  Object o) {
        return (view==(LinearLayout)o);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view=inflater.inflate(R.layout.slide,container,false);
        LinearLayout layoutslide=(LinearLayout) view.findViewById(R.id.slidelinearlayout);
        ImageView imgslide = (ImageView) view.findViewById(R.id.slideimg);
        TextView txttitle=(TextView) view.findViewById(R.id.txttitle);
        TextView description=(TextView) view.findViewById(R.id.txtdescription);
        layoutslide.setBackgroundColor(list_backgroundcolor[position]);
        imgslide.setImageResource(list_images[position]);
        txttitle.setText(list_title[position]);
        description.setText(list_descruption[position]);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem( ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout)object);
    }

}

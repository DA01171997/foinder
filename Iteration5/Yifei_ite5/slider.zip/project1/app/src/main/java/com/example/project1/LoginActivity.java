package com.example.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    private Button sig;
    private Button log;
    EditText UserE;
    EditText Password;
    String name;
    String pass;

    View focusView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        UserE=(EditText)findViewById(R.id.logUseremail);
        Password=(EditText)findViewById(R.id.regPassword);

        sig=(Button)findViewById(R.id.regbutton);
        sig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openreg();
            }
        });

        log=(Button)findViewById(R.id.logbutton);
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openlog();
            }
        });

    }

    public void openreg(){
        Intent intent=new Intent(this,RegisterActivity.class);
        startActivity(intent);
        finish();
    }

    public void openlog(){
        name=UserE.getText().toString();
        pass=Password.getText().toString();
        if (TextUtils.isEmpty(name)){
            UserE.setError(getString(R.string.error_field_required));
            focusView = UserE;
        }

        if (TextUtils.isEmpty(pass)) {
            Password.setError(getString(R.string.error_field_required));
            focusView = Password;
        }
        if (valiadate(name, pass)) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            Password.setError(getString(R.string.error_incorrect_password));
            focusView = Password;
        }
    }

    //match data
    private boolean valiadate(String user,String pass){
        String UE="Yifei";
        String pw="1234";
        if((user.equals(UE))&&(pass.equals(pw))){
            return true;
        }
        else return false;
    }

}

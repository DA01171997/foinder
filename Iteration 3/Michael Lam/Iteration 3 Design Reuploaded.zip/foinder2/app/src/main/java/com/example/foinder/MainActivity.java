package com.example.foinder;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private ViewPager viewpager;
    private SlideAdapter myadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewpager = (ViewPager) findViewById(R.id.viewpager);
        myadapter = new SlideAdapter(this);
        viewpager.setAdapter(myadapter);

        // Get the button
       // Button btn = (Button) findViewById(R.id.btnDoMagic);
        // Receives Menu after pressing button
      //  btn.setOnClickListener(new View.OnClickListener() {
        //    @Override
       //     public void onClick(View v) {
      //          Toast.makeText(getApplicationContext(), "Here's the Menu", Toast.LENGTH_SHORT).show();
 //           }

 //       });
    }
}

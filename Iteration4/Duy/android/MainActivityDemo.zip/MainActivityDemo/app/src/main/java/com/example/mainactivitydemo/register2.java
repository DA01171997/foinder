package com.example.mainactivitydemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class register2 extends AppCompatActivity {
    EditText rName, rBirthday, rEmail, rPassword;
    String strRName, strRBirthday, strREmail, strRPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register2);
        rName = (EditText) findViewById(R.id.rName);
        rBirthday = (EditText) findViewById(R.id.rBirthday);
        rEmail = (EditText) findViewById(R.id.rEmail);
        rPassword = (EditText) findViewById(R.id.rPassword);
    }
    public void OnReg (View view) throws ParseException {
        strRName = rName.getText().toString();
        //SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        //String  = formatter.parse(rBirthday.getText().toString());
        //String newDateStr = formatter.format(formatter.parse(rBirthday.getText().toString()));
        //strRBirthday = newDateStr;
        //rBirthday = toString(dateObj.getYear())
        //+ "-"+  dateObj.getMonth() + "-"+ dateObj.getDate();
        strREmail = rEmail.getText().toString();
        strRPassword = rPassword.getText().toString();
        strRBirthday=rBirthday.getText().toString();
        //strRName = "test7";
        //strRBirthday="2001-01-01";
        //strREmail = "test7@gmail.com";
        //strRPassword = "test7";
        String type="Register";
        BackgroundWorker backgroundWorker = new BackgroundWorker((this));
        backgroundWorker.execute(type,strRName,strRBirthday,strREmail,strRPassword);
    }
}

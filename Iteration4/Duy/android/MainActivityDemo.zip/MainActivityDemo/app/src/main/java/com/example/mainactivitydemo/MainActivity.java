package com.example.mainactivitydemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText EmailET, PasswordET;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EmailET = (EditText) findViewById(R.id.emailET);
        PasswordET = (EditText) findViewById((R.id.passwordET));
    }
    public void OnLogin(View view){
        String email = EmailET.getText().toString();
        String password = PasswordET.getText().toString();
        String type="login";
        BackgroundWorker backgroundWorker = new BackgroundWorker((this));
        backgroundWorker.execute(type,email,password);
    }
    public void OnRegister (View view){
        startActivity(new Intent(this, register2.class));
    }
}
